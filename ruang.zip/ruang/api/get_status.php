<?php
require_once __DIR__ . '/../db.php';

$room_id = $_GET['room_id'] ?? null;

if (!$room_id) {
    echo "ERROR: missing room_id";
    exit;
}

$stmt = $pdo->prepare("SELECT current_status FROM rooms WHERE id=?");
$stmt->execute([$room_id]);

$data = $stmt->fetch(PDO::FETCH_ASSOC);

echo $data ? $data['current_status'] : "not_found";
