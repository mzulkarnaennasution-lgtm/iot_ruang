// simple polling to refresh status every 5s
async function fetchStatus(){
  try {
    const res = await fetch('api/status_all.php');
    const data = await res.json();
    if (!data.ok) return;
    data.rooms.forEach(r => {
      const el = document.querySelector('.room[data-id="'+r.id+'"]');
      if (el) {
        el.querySelector('.status span').textContent = r.current_status;
        el.style.background = r.current_status === 'occupied' ? '#ffecec' : '#ecffe8';
      }
    });
  } catch (e) {
    console.error(e);
  }
}

setInterval(fetchStatus, 5000);
fetchStatus();
