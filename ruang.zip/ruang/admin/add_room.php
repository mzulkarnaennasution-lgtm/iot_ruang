<?php
require_once __DIR__ . '/../db.php';
session_start();

if (isset($_POST['save'])) {
    $name        = trim($_POST['name'] ?? '');
    $location    = trim($_POST['location'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $imagePath   = null;

    if ($name === '' || $location === '') {
        $error = "Nama dan lokasi wajib diisi.";
    } else {

        if (!empty($_FILES['image']['name'])) {

            $folder = "../uploads/";
            if (!is_dir($folder)) mkdir($folder, 0777, true);

            $fileName  = time() . "_" . basename($_FILES["image"]["name"]);
            $target    = $folder . $fileName;

            $ext = strtolower(pathinfo($target, PATHINFO_EXTENSION));
            $allowed = ["jpg","jpeg","png","webp"];

            if (!in_array($ext, $allowed)) {
                $error = "Format gambar harus JPG, JPEG, PNG, atau WEBP.";
            } else {
                if (move_uploaded_file($_FILES["image"]["tmp_name"], $target)) {
                    $imagePath = "uploads/" . $fileName;
                } else {
                    $error = "Gagal upload gambar.";
                }
            }
        }
        if (empty($error)) {
            $stmt = $pdo->prepare("
                INSERT INTO rooms (name, location, description, current_status, image)
                VALUES (:name, :location, :description, 'free', :image)
            ");

            try {
                $stmt->execute([
                    ':name'        => $name,
                    ':location'    => $location,
                    ':description' => ($description === '' ? null : $description),
                    ':image'       => $imagePath
                ]);

                header("Location: rooms.php?success=1");
                exit;

            } catch (Exception $e) {
                $error = "Gagal menyimpan: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Tambah Ruangan</title>
    <style>
        body { font-family: Arial; background:#e8f5e9; padding:40px; }
        .form-box { 
            background:white; padding:20px; width:420px; border-radius:10px; 
            box-shadow:0 4px 10px rgba(0,0,0,.1); margin:auto; 
        }
        input, textarea { width:100%; padding:10px; margin:10px 0; 
            border-radius:8px; border:1px solid #aaa; }
        button { padding:12px; width:100%; background:#43a047; 
            color:white; border:none; border-radius:8px; cursor:pointer; }
        button:hover { background:#2e7d32; }
        a { text-decoration:none; color:#2e7d32; display:block; text-align:center; margin-top:15px; }
        .error{color:#b00020;margin-bottom:10px}
    </style>
</head>
<body>

<div class="form-box">
    <h2>Tambah Ruangan</h2>

    <?php if (!empty($error)): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="Nama Ruangan (ex: A101)" required>
        <input type="text" name="location" placeholder="Lokasi (ex: Gedung Teknik Lt.1)" required>
        <textarea name="description" placeholder="Deskripsi (opsional)"></textarea>

        <label>Upload Gambar</label>
        <input type="file" name="image" accept="image/*">

        <button name="save" type="submit">Simpan</button>
    </form>

    <a href="rooms.php">← Kembali</a>
</div>

</body>
</html>
