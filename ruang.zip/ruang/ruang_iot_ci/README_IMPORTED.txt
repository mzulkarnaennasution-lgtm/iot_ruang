
Paket CodeIgniter-style yang berisi proyek legacy (ruang_iot) di folder /legacy.
Untuk menjalankan di local (xampp):
 - Extract isi zip ke htdocs/ruang_iot_ci
 - Pastikan document root menunjuk ke folder public/
 - Akses http://localhost/ruang_iot_ci/ -> akan memuat legacy/index.php (user)
 - Akses http://localhost/ruang_iot_ci/admin -> akan memuat legacy/admin/dashboard.php
Catatan: koneksi DB masih menggunakan file legacy/db.php; sesuaikan konfigurasi database di legacy/db.php
