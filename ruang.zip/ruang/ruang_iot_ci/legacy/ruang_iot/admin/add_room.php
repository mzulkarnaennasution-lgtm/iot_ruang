<?php
require_once __DIR__ . '/../db.php';
session_start();

// cek admin login, simple check (sesuaikan dengan login yang kamu punya)
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

if (isset($_POST['save'])) {
    $name = trim($_POST['name'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $description = trim($_POST['description'] ?? '');

    if ($name === '' || $location === '') {
        $error = "Nama dan lokasi wajib diisi.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO rooms (name, location, description, current_status) VALUES (:name, :location, :description, 'free')");
        try {
            $stmt->execute([
                ':name' => $name,
                ':location' => $location,
                ':description' => $description === '' ? null : $description
            ]);
            header("Location: rooms.php?success=1");
            exit;
        } catch (Exception $e) {
            $error = "Gagal menyimpan: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Tambah Ruangan</title>
    <style>
        body { font-family: Arial; background:#e8f5e9; padding:40px; }
        .form-box { background:white; padding:20px; width:420px; border-radius:10px; box-shadow:0 4px 10px rgba(0,0,0,.1); margin:auto; }
        input, textarea { width:100%; padding:10px; margin:10px 0; border-radius:8px; border:1px solid #aaa; }
        button { padding:12px; width:100%; background:#43a047; color:white; border:none; border-radius:8px; cursor:pointer; }
        button:hover { background:#2e7d32; }
        a { text-decoration:none; color:#2e7d32; display:block; text-align:center; margin-top:15px; }
        .error{color:#b00020;margin-bottom:10px}
    </style>
</head>
<body>

<div class="form-box">
    <h2>Tambah Ruangan</h2>
    <?php if (!empty($error)): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
        <input type="text" name="name" placeholder="Nama Ruangan (ex: A101)" required>
        <input type="text" name="location" placeholder="Lokasi (ex: Gedung Teknik Lt.1)" required>
        <textarea name="description" placeholder="Deskripsi (opsional)"></textarea>
        <button name="save" type="submit">Simpan</button>
    </form>
    <a href="rooms.php">← Kembali</a>
</div>

</body>
</html>
