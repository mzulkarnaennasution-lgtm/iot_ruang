<?php
require_once __DIR__ . '/../db.php';
session_start();

// Cek login admin
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

// Ambil semua ruangan
$rooms = $pdo->query("SELECT * FROM rooms ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

// Proses hapus ruangan
if (isset($_GET["delete"])) {
    $id = $_GET["delete"];
    $del = $pdo->prepare("DELETE FROM rooms WHERE id=?");
    $del->execute([$id]);

    echo "<script>alert('Ruangan dihapus');window.location='rooms.php';</script>";
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Kelola Ruangan</title>
    <link rel="stylesheet" href="../assets/css/style.css">

    <style>
        .status-free {
            color: green;
            font-weight: bold;
        }
        .status-occupied {
            color: red;
            font-weight: bold;
        }
        table td, table th {
            padding: 10px;
        }
    </style>
</head>

<body>

<div class="header">
    <div class="brand">Ruang Admin</div>
    <div class="user">
        Hai, <?= $_SESSION['admin'] ?> |
        <a href="logout.php" style="color:#fff">Logout</a>
    </div>
</div>

<div class="container grid">

    <div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="rooms.php" class="active">Ruangan</a>
        <a href="history.php">History</a>
        <a href="#">User</a>
    </div>

    <div class="content">
        <div class="card">

            <h2>Kelola Ruangan</h2>

            <a href="add_room.php" class="btn">➕ Tambah Ruangan</a>
            <br><br>

            <table class="table" border="1" cellspacing="0" width="100%">
                <tr>
                    <th>ID</th>
                    <th>Nama Ruangan</th>
                    <th>Lokasi</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>

                <?php foreach ($rooms as $r): ?>
                <tr>
                    <td><?= $r["id"] ?></td>
                    <td><?= htmlspecialchars($r["name"]) ?></td>
                    <td><?= htmlspecialchars($r["location"]) ?></td>
                    
                    <td>
                        <?php if ($r["current_status"] === "occupied"): ?>
                            <span class="status-occupied">BERISI</span>
                        <?php else: ?>
                            <span class="status-free">KOSONG</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <a href="edit_room.php?id=<?= $r['id'] ?>">Edit</a> |
                        <a href="rooms.php?delete=<?= $r['id'] ?>" 
                           onclick="return confirm('Hapus ruangan ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>

        </div>
