<?php
require_once __DIR__ . '/../db.php';
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

// Hitung data
$count_user = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$occupied   = $pdo->query("SELECT COUNT(*) FROM rooms WHERE current_status='occupied'")->fetchColumn();
$free       = $pdo->query("SELECT COUNT(*) FROM rooms WHERE current_status='free'")->fetchColumn();

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">

    <style>
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 25px;
            margin-top: 25px;
        }

        .card-box {
            padding: 25px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .card-box img {
            width: 80px;
            height: 80px;
        }

        .card-text h3 {
            margin: 0;
            font-size: 20px;
        }

        .count-number {
            font-size: 38px;
            font-weight: bold;
            margin-top: 5px;
        }

        .green { color: #2e7d32; }
        .red   { color: #c62828; }
        .blue  { color: #1565c0; }
    </style>
</head>

<body>

<div class="header">
    <div class="brand">Dashboard Admin</div>
    <div class="user">
        Hai, <?= $_SESSION['admin'] ?> |
        <a href="logout.php" style="color:#fff">Logout</a>
    </div>
</div>

<div class="container grid">

    <div class="sidebar">
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="rooms.php">Ruangan</a>
        <a href="history.php">History</a>
        <a href="users.php">User</a>
    </div>

    <div class="content">

        <h2>Dashboard Statistik</h2>

        <div class="dashboard-grid">

            <!-- TOTAL USER -->
            <div class="card-box">
                <img src="../assets/img/user.png" alt="User">
                <div class="card-text">
                    <h3>Total User</h3>
                    <div class="count-number blue"><?= $count_user ?></div>
                </div>
            </div>

            <!-- RUANGAN BERISI -->
            <div class="card-box">
                <img src="../assets/img/occupied.png" alt="Berisi">
                <div class="card-text">
                    <h3>Ruangan Berisi</h3>
                    <div class="count-number red"><?= $occupied ?></div>
                </div>
            </div>

            <!-- RUANGAN KOSONG -->
            <div class="card-box">
                <img src="../assets/img/free.png" alt="Kosong">
                <div class="card-text">
                    <h3>Ruangan Kosong</h3>
                    <div class="count-number green"><?= $free ?></div>
                </div>
            </div>

        </div>

    </div>

</div>

</body>
</html>
