<?php
require_once __DIR__ . '/../db.php';
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$sql = "
    SELECT 
        rs.timestamp,
        rs.status,
        r.name AS room_name,
        rs.room_id
    FROM room_history rs
    JOIN rooms r ON rs.room_id = r.id
    ORDER BY rs.room_id, rs.timestamp ASC
";


$rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

$results = [];
$last_in = []; // menyimpan waktu masuk terakhir

foreach ($rows as $row) {
    $room_id  = $row["room_id"];
    $status   = $row["status"];
    $time     = $row["timestam"];

    if ($status === "occupied") {
        // Catat waktu masuk
        $last_in[$room_id] = $time;
    } 
    elseif ($status === "free" && isset($last_in[$room_id])) {
        // Jika keluar → hitung durasi
        $masuk = strtotime($last_in[$room_id]);
        $keluar = strtotime($time);

        $durasi = ($keluar - masuk) / 3600; // ke jam

        if ($durasi >= 2) {
            $results[] = [
                "room" => $row["room_name"],
                "masuk" => $last_in[$room_id],
                "keluar" => $time,
                "durasi" => round($durasi, 2)
            ];
        }

        unset($last_in[$room_id]); // reset setelah keluar
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>History > 2 Jam</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<div class="header">
    <div class="brand">History Ruangan</div>
    <div class="user">
        Hai, <?= $_SESSION['admin'] ?> |
        <a href="logout.php" style="color:#fff">Logout</a>
    </div>
</div>

<div class="container grid">

    <div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="rooms.php">Ruangan</a>
        <a href="history.php" class="active">History</a>
        <a href="users.php">User</a>
    </div>

    <div class="content">

        <h2>History (Lama di ruangan ≥ 2 Jam)</h2>

        <table class="table">
            <tr>
                <th>Ruangan</th>
                <th>Waktu Masuk</th>
                <th>Waktu Keluar</th>
                <th>Durasi (Jam)</th>
            </tr>

            <?php foreach ($results as $h): ?>
            <tr>
                <td><?= $h['room'] ?></td>
                <td><?= $h['masuk'] ?></td>
                <td><?= $h['keluar'] ?></td>
                <td><?= $h['durasi'] ?></td>
            </tr>
            <?php endforeach; ?>

            <?php if (empty($results)): ?>
            <tr>
                <td colspan="4">Tidak ada mahasiswa yang berada lebih dari 2 jam.</td>
            </tr>
            <?php endif; ?>

        </table>

    </div>
</div>

</body>
</html>
