<?php
require_once __DIR__ . '/../db.php';
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$id = $_GET["id"];
$q = $pdo->prepare("SELECT * FROM rooms WHERE id=?");
$q->execute([$id]);
$room = $q->fetch(PDO::FETCH_ASSOC);

if (!$room) {
    die("Ruangan tidak ditemukan!");
}

if (isset($_POST["submit"])) {
    $name = $_POST["name"];
    $status = $_POST["status"];

    $update = $pdo->prepare("UPDATE rooms SET name=?, current_status=? WHERE id=?");
    $update->execute([$name, $status, $id]);

    echo "<script>alert('Ruangan diperbarui');window.location='rooms.php';</script>";
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Ruangan</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<div class="header">
    <div class="brand">Ruang Admin</div>
    <div class="user">
        Hai, <?= $_SESSION['admin'] ?> | <a href="logout.php" style="color:#fff">Logout</a>
    </div>
</div>

<div class="container grid">

    <div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="rooms.php" class="active">Ruangan</a>
        <a href="history.php">History</a>
    </div>

    <div class="content">
        <div class="card">
            <h2>Edit Ruangan</h2>

            <form method="POST">
                <label>Nama Ruangan</label><br>
                <input type="text" name="name" value="<?= $room['name'] ?>" required><br><br>

                <label>Status</label><br>
                <select name="status">
                    <option value="empty"   <?= $room['current_status']=="empty" ? "selected":"" ?>>Kosong</option>
                    <option value="occupied" <?= $room['current_status']=="occupied" ? "selected":"" ?>>Terisi</option>
                </select>
                <br><br>

                <button type="submit" name="submit" class="btn">Update</button>
            </form>
        </div>
    </div>

</div>
</body>
</html>
