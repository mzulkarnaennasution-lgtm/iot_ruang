<?php
require_once 'db.php';
$rooms = $pdo->query('SELECT * FROM rooms ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ruang IoT - Lihat Ruangan</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
  <div class="container">
    <h1>Daftar Ruangan</h1>
    <div id="rooms">
      <?php foreach($rooms as $r): ?>
        <div class="room" data-id="<?= $r['id'] ?>">
          <h3><?= htmlspecialchars($r['name']) ?></h3>
          <p><?= htmlspecialchars($r['location']) ?></p>
          <p class="status">Status: <span><?= $r['current_status'] ?></span></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
<script src="assets/js/main.js"></script>
</body>
</html>
