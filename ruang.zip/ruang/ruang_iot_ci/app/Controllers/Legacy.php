<?php
namespace App\Controllers;

class Legacy extends BaseController
{
    protected $legacyPath;

    public function __construct()
    {
        // path to legacy (original) project copied into project root
        $this->legacyPath = realpath(__DIR__ . '/../../legacy');
    }

    public function index()
    {
        // show user index (legacy/index.php)
        $file = $this->legacyPath . '/index.php';
        if (file_exists($file)) {
            require $file;
        } else {
            echo 'Legacy index not found';
        }
    }

    public function admin($page = 'dashboard.php')
    {
        // map admin pages: call legacy/admin/<page>
        $file = $this->legacyPath . '/admin/' . $page;
        if (file_exists($file)) {
            // simple session handling: ensure session_started in legacy files may rely on relative paths
            require $file;
        } else {
            echo 'Admin page not found: ' . htmlspecialchars($page);
        }
    }

    public function api($file = 'status_all.php')
    {
        $f = $this->legacyPath . '/api/' . $file;
        if (file_exists($f)) {
            require $f;
        } else {
            echo 'API file not found: ' . htmlspecialchars($file);
        }
    }
}
