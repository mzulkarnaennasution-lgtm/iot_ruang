<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');


// --- Added legacy routes by assistant
$routes->get('/', 'Legacy::index');
$routes->get('admin/(:any)', 'Legacy::admin/$1');
$routes->get('api/(:any)', 'Legacy::api/$1');
$routes->get('admin', 'Legacy::admin/dashboard.php');
