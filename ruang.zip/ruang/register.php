<?php
require_once __DIR__ . '/db.php';
session_start();

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);

    // Validasi sederhana
    if ($username == "" || $password == "" || $name == "" || $email == "") {
        $error = "Semua field wajib diisi!";
    } else {

        // Cek username apakah sudah dipakai
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username=? LIMIT 1");
        $stmt->execute([$username]);

        if ($stmt->rowCount() > 0) {
            $error = "Username sudah digunakan!";
        } else {

            // Upload foto jika ada
            $photoName = "default.png";

            if (!empty($_FILES['photo']['name'])) {

                $img = $_FILES['photo'];
                $ext = pathinfo($img['name'], PATHINFO_EXTENSION);

                // Nama file unik
                $photoName = time() . "_" . rand(1000,9999) . "." . $ext;
                $uploadPath = __DIR__ . "/uploads/" . $photoName;

                move_uploaded_file($img['tmp_name'], $uploadPath);
            }

            // Insert user baru
            $stmt = $pdo->prepare("INSERT INTO users (username, password, role, name, email, photo)
                                   VALUES (?, ?, 'user', ?, ?, ?)");

            $stmt->execute([
                $username,
                password_hash($password, PASSWORD_DEFAULT),
                $name,
                $email,
                $photoName
            ]);

            $success = "Akun berhasil dibuat! Silakan login.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Akun</title>
    <link rel="stylesheet" href="assets/css/login1.css">
</head>

<body>

<div class="login-container">
    <div class="login-card">

        <img src="assets/img/umri1.png" class="logo">

        <h2>Buat Akun Baru</h2>
        <p class="subtitle">Isi data di bawah untuk mendaftar</p>

        <?php if ($error): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>

        <?php if ($success): ?>
            <p class="success"><?= $success ?></p>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">

            <div class="input-group">
                <label>Nama Lengkap</label>
                <input type="text" name="name" required placeholder="Masukkan nama anda">
            </div>

            <div class="input-group">
                <label>Email</label>
                <input type="email" name="email" required placeholder="Masukkan email">
            </div>

            <div class="input-group">
                <label>Username</label>
                <input type="text" name="username" required placeholder="Masukkan username">
            </div>

            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" required placeholder="Masukkan password">
            </div>

            <div class="input-group">
                <label>Foto Profil (Opsional)</label>
                <input type="file" name="photo" accept="image/*">
            </div>

            <button type="submit" class="btn-login">Daftar</button>

        </form>

        <p style="margin-top:15px;">
            Sudah punya akun?  
            <a href="login.php">Masuk di sini</a>
        </p>

    </div>
</div>

</body>
</html>
